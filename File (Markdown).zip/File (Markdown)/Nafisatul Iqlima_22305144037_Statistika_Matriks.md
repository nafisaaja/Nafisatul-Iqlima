﻿# Nafisatul Iqlima_22305144037_Statistika_Matriks
Nama  : Nafisatul Iqima


NIM   : 22305144037


Kelas : Matematika E 2022


# Array

Array adalah kumpulan-kumpulan variabel yang menyimpan data dengan
tipe yang sama atau data-data yang tersusun secara linear dimana di
dalamnya terdapat elemen dengan tipe yang sama.


Vektor digunakan untuk menggambarkan array angka satu dimensi. Vektor
memiliki panjang, yang merupakan jumlah elemen dalam array.


Sedangkan matriks digunakan dalam mendeskripsikan susunan bilangan dua


dimensi yang disusun dalam baris dan kolom. matriks memiliki ukuran,
yaitu jumlah baris dan kolom.


Hubungan antara array dan matriks adalah bahwa matriks adalah bentuk
khusus dari array. Array dapat memiliki lebih dari dua dimensi, tetapi
matriks selalu memiliki dua dimensi. Dalam pemrograman, array dan
matriks sering digunakan untuk menyimpan data dalam jumlah besar dan
memudahkan pengaksesan data tersebut.


Mari kita bahas beberapa hal terkait vektor terlebih dahulu


\>v=shuffle(1:10)


    [6,  3,  1,  5,  10,  4,  9,  8,  2,  7]

\>w=intrandom(10,12)


    [11,  4,  9,  3,  6,  4,  11,  3,  6,  2]

Untuk mengurutkan angka acak 


\>sort(v)


    [1,  2,  3,  4,  5,  6,  7,  8,  9,  10]

Selanjutnya mengurutkan angka acak dengan menyederhanakan angka yang
sama


\>unique(v)


    [1,  2,  3,  4,  5,  6,  7,  8,  9,  10]

Menemukan banyaknya setiap elemen dengan bantuan interval


\>s=intrandom(10,20)


    [12,  9,  15,  10,  7,  11,  11,  4,  6,  18]

\>x=[5,10,15,20]


    [5,  10,  15,  20]

\>find(x,s)


    [2,  1,  3,  2,  1,  2,  2,  0,  1,  3]

Berikutnya adalah cara mencari indeks dari sebuah vektor.Untuk indeks
pada EMT berbeda dengan indeks pada Phyton yang kita pelajari
sebelumnya di Algoritma dan pemrograman. Perbedaannya juka sebelumnya
untk menentukan indeks akan dimulalai dari nol namun di mmenentukan
indeks di EMT akan dimulai dari angka satu, berikut penjelasannya


\>indexof(s,1:20)


    [0,  0,  0,  8,  0,  9,  5,  0,  2,  4,  6,  1,  0,  0,  3,  0,  0,
    10,  0,  0]

\>x= sort(intrandom(25,25))


    [1,  2,  5,  5,  5,  5,  6,  8,  9,  9,  9,  11,  12,  12,  13,  14,
    14,  15,  16,  17,  19,  19,  24,  25,  25]

\>indexofsorted(x,1:25)


    [1,  2,  0,  0,  6,  7,  0,  8,  11,  0,  12,  14,  15,  17,  18,  19,
    20,  0,  22,  0,  0,  0,  0,  23,  25]

Menghitung jumlah dari elemen yang ada pada vektor z


\>z=intrandom(1000,10); multofsorted(sort(z),1:10), sum(%)


    [82,  96,  120,  99,  100,  91,  116,  99,  102,  95]
    1000

Sampai disini pembahasan terkait dengan vektor


Selanjutnya kita akan membahas  beberapa hal terkait matriks terkait


Untuk Menyimpan Data dalam bentuk Matrik


Pertama, buat sebuah variabel yang akan menampung data matrik, misal
X. Variabel ini bebas dengan syarat tidak sama dengan nama fungsi atau
konstanta yang sudah ada dalam software.


Selanjutnya,kita akan membuat matrik berordo mxn yang berisi angka


\>X=[1,2,3,4;4,5,6,7;8,4,4,6;3,5,8]


                1             2             3             4 
                4             5             6             7 
                8             4             4             6 
                3             5             8             0 

\>shortformat; A=random(3,4)


      0.89964   0.33579   0.92642   0.55015 
      0.38363   0.22129   0.84452   0.54917 
      0.47611   0.71646 0.0070492   0.99675 

\>shortformat; A=intrandom(4,5,10)


            4         6         7         5         1 
            8         5         3         2         2 
           10         5         1         6         5 
            3         3         5         5         5 

\>shortformat; A=redim(1:20,4,5)


            1         2         3         4         5 
            6         7         8         9        10 
           11        12        13        14        15 
           16        17        18        19        20 

\>(1:4)\_ 3\_1


            1         2         3         4 
            3         3         3         3 
            1         1         1         1 

\>random(3,3)\_random(2,2)


      0.65175   0.42793   0.88514 
      0.73055   0.22365   0.72575 
      0.49576   0.48018 0.0030896 
     0.086471   0.85575         0 
      0.90892  0.072976         0 

\>for k=1 to prod(size(A)); A{k}=k; end; short A


            1         2         3         4         5 
            6         7         8         9        10 
           11        12        13        14        15 
           16        17        18        19        20 

\>B=zeros(size(A))


            0         0         0         0         0 
            0         0         0         0         0 
            0         0         0         0         0 
            0         0         0         0         0 

\>B=ones(size(A))


            1         1         1         1         1 
            1         1         1         1         1 
            1         1         1         1         1 
            1         1         1         1         1 

Berikutnya operasi penjumlahan dam pengurangan matriks


\>shortformat; I=intrandom(3,4,10) 


            4         4         9         7 
            9         2         1         2 
            8        10         6         5 

\>shortformat; J=intrandom(3,4,8)


            4         1         7         3 
            8         7         2         3 
            5         6         3         3 

\>C= I-J


            0         3         2         4 
            1        -5        -1        -1 
            3         4         3         2 

\>C= I+J


            8         5        16        10 
           17         9         3         5 
           13        16         9         8 

Dalam materi matriks yang pernah kita pelajari ada sebutan transpose,
Invers dan juga determinan, jika menggunakan EMt sebagai berikut
secera berurutan:


\>T = transpose(I)


            4         9         8 
            4         2        10 
            9         1         6 
            7         2         5 

\>T = I'


            4         9         8 
            4         2        10 
            9         1         6 
            7         2         5 

\>K = J^(-1)


         0.25         1   0.14286   0.33333 
        0.125   0.14286       0.5   0.33333 
          0.2   0.16667   0.33333   0.33333 

\>shortformat; L=intrandom(3,3,7)


            1         7         7 
            1         3         7 
            2         3         3 

\>det(L)


    44

\>shortformat; L=intrandom(3,3,7)


            4         5         6 
            6         1         4 
            2         5         4 

Selanjutnya adalah cara ekstraksi baris dan kolom, atau
sub-matriks,yang  mirip dengan R sebagai berikut:


\>L[1:2,2:3]


            5         6 
            1         4 

\>shortformat; X=redim(1:20,4,5)


            1         2         3         4         5 
            6         7         8         9        10 
           11        12        13        14        15 
           16        17        18        19        20 

\>function setmatrixvalue (M, i, j, v) ...


    loop 1 to max(length(i),length(j),length(v))
       M[i{#},j{#}] = v{#};
    end;
    endfunction
</pre>
\>setmatrixvalue(X,1:4,4:-1:1,2); X,


            1         2         3         2         5 
            6         7         2         9        10 
           11         2        13        14        15 
            2        17        18        19        20 

\>(1:4)\*(1:4)'


            1         2         3         4 
            2         4         6         8 
            3         6         9        12 
            4         8        12        16 

\>a=0:10; b=a'; p=flatten(a\*b); q=flatten(p-p'); ...  
\>   u=sort(unique(q)); f=getmultiplicities(u,q); ...  
\>   statplot(u,f,"h"):


![images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-001.png](images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-001.png)

\>getfrequencies(q,-50:10:50)


    [613,  814,  1088,  1404,  1904,  2389,  1431,  1109,  841,  680]

\> plot2d(q,distribution=11):


![images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-002.png](images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-002.png)

\>{x,y}=histo(q,v=-55:10:55); y=y/sum(y)/differences(x); ...  
\>   plot2d(x,y,\>bar,style="/"):


![images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-003.png](images/Nafisatul%20Iqlima_22305144037_Statistika_Matriks-003.png)

